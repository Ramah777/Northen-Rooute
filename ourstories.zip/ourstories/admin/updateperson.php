<?php
/*
	file:	admin/updateperson.php
	desc:	Updates person-table with given fields
*/
if(empty($_POST)) header('location:index.php');
include('../db.php');
$error=false;
if(!empty($_POST['personID'])) $personID=$_POST['personID'];else $error=true;
if(!empty($_POST['lastname'])) $lastname=$_POST['lastname'];else $error=true;
if(!empty($_POST['firstname'])) $firstname=$_POST['firstname'];else $error=true;
if(!empty($_POST['email'])) $email=$_POST['email'];else $error=true;
if(!empty($_POST['salary'])) $salary=$_POST['salary'];else $error=true;
if(!empty($_POST['department'])) $department=$_POST['department'];else $department=0;
if(!$error){
	$sql="UPDATE person SET lastname='$lastname',firstname='$firstname',
		  email='$email',salary=$salary
		  WHERE personID=$personID";
	$conn->query($sql);
	//check if person does not have department
	$sql="SELECT * FROM placement WHERE personID=$personID";
	$result=$conn->query($sql);
	if($result->num_rows>0){
		$sql="UPDATE placement SET depID=$department
			  WHERE personID=$personID";
	}else $sql="INSERT INTO placement VALUES($personID,$department)";
	$conn->query($sql);
	session_start();
	$_SESSION['msg']='<h5 class="alert alert-success">Updated!</h5>';
}else $_SESSION['msg']='<h5 class="alert alert-danger">Could not update!</h5>';
$conn->close();
header("location:index.php?page=editperson&personID=$personID");	
?>





