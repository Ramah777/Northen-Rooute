<?php
/*
	file:	admin/deleteperson.php
	desc:	Reads personID from get-list and deletes that record
			from database table person. Removes all placements from
			placement-table with that personID.
*/
if(!empty($_GET['personID'])) $personID=$_GET['personID'];
else header('location:index.php?page=');
include('../db.php');
$sql="DELETE FROM person WHERE personID=$personID";
$conn->query($sql);
$sql="DELETE FROM placement WHERE personID=$personID";
$conn->query($sql);
header('location:index.php?page=persons');
?>