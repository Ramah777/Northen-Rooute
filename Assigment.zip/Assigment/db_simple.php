<?php
/*
	file:	db_simple.php
*/
$conn=new mysqli('localhost','personnel','personnel','personnel');
?>