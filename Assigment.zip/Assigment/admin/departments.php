<?php
/*
	file:	admin/departments.php
	desc:	Displays list of departments and form to add
*/
?>
<h4>Departments</h4>
<h3 data-toggle="collapse" data-target="#addform">Add department +</h3>
  <div id="addform" class="collapse">
    <form action="addDepartment.php" method="post">
		Name: <input type="text" name="department" placeholder="Department name" />
		<input type="submit" value="Add department" />
	</form>
  </div>

<h3 data-toggle="collapse" data-target="#list">Departments</h3>
  <div id="list" class="collapse in">
    <table class="table table-striped">
		<tr>
			<th>id#</th>
			<th>Name of department</th>
			<th></th>
			<?php
				include('../db.php');
				$sql="SELECT * FROM department ORDER BY department";
				$result=$conn->query($sql);
				while($row=$result->fetch_assoc()){
					echo '<tr>';
					echo '<td>'.$row['depID'].'</td>';
					echo '<td>'.$row['department'].'</td>';
					echo '<td><a href="index.php?page=editdepartment&depID='.$row['depID'].'">Edit</a></td>';
					echo '</tr>';
				}
				$conn->close();
			?>
		</tr>
	</table>
  </div>
  
  
  
  
  
  
  