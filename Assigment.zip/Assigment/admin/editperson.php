<?php
/*
	file:	admin/editperson.php
	desc:	Displays a form where person with given id can be 
			edited
*/
if(!empty($_GET['personID'])) $personID=$_GET['personID'];else $personID=0;
include('../db.php');
$sql="SELECT * FROM person 
	  LEFT JOIN placement
	  ON person.personID=placement.personID
	  LEFT JOIN department
	  ON placement.depID=department.depID
	  WHERE person.personID=$personID";
$result=$conn->query($sql);  //runs the query in database
if($result->num_rows>0){
	$row=$result->fetch_assoc();
	echo '<h4>Edit person data</h3>';
	if(isset($_SESSION['msg'])){
		echo $_SESSION['msg'];
		$_SESSION['msg']='';
	}
	echo '<form action="updateperson.php" method="post">
			<input type="hidden" name="personID" value="'.$personID.'" />
			Lastname <input type="text" name="lastname" value="'.$row['lastname'].'" /><br />
			Firstname <input type="text" name="firstname" value="'.$row['firstname'].'" /><br />
			Email <input type="email" name="email" value="'.$row['email'].'" /><br />
			Salary <input type="text" name="salary" value="'.$row['salary'].'" /><br />
			Department <select name="department">
						<option value="">-Select-</option>';
					$sql="SELECT depID,department FROM department
						  ORDER BY department";
					$result=$conn->query($sql);
					while($row1=$result->fetch_assoc()){
						echo '<option value="'.$row1['depID'].'"';
						if($row1['depID']==$row['depID']) echo ' selected ';
						echo '>'.$row1['department'].'</option>';
					}
	echo '				</select><br />
			<input type="submit" value="Update" />
		  </form>';
	echo '<h5>To remove the person from db, click here</h5>';
	echo '<p><form action="index.php?page=removeperson" method="post">';
    echo '<input type="hidden" name="personID" value="'.$personID.'" />';
	echo '<input type="submit" value="Remove person from database" />';
    echo '</form></p>';	
}else echo '<h4>No record found</h4>';
?>






