<?php
/*
	file:	admin/updateDepartment.php
	desc:	Updates department name
*/
$error=false;
if(!empty($_POST['depID'])) $depID=$_POST['depID'];else $error=true;
if(!empty($_POST['department'])) $department=$_POST['department'];else $error=true;
if(!empty($_POST['removedep'])) $removedep=$_POST['removedep'];else $removedep='';
if(!$error){
	include('../db.php');
	$sql="UPDATE department SET department='$department' WHERE depID=$depID";
	$conn->query($sql);
	if(!empty($removedep)){
		$sql="DELETE FROM department WHERE depID=$depID";
		$conn->query($sql);
		if($conn->query($sql)===TRUE) header("location:index.php?page=department");
	}else   if($conn->query($sql)===TRUE) header("location:index.php?page=editdepartment&depID=$depID&update=ok");
			else header('location:index.php');
}else header('location:index.php');
?>