<?php
/*
	file:	admin/insertPerson.php
	desc:	Reads form fields coming lastname, firstname, email
			salary and department. Inserts them into table person in db
*/
if(empty($_POST)) header('location:index.php');
include('../db.php');
$error=false;
if(!empty($_POST['lastname'])) $lastname=$_POST['lastname'];else $error=true;
if(!empty($_POST['firstname'])) $firstname=$_POST['firstname'];else $error=true;
if(!empty($_POST['email'])) $email=$_POST['email'];else $error=true;
if(!empty($_POST['salary'])) $salary=$_POST['salary'];else $error=true;
if(!empty($_POST['department'])) $department=$_POST['department'];else $department=0;
if(!$error){
	//here i could check that same values do not exist
	$sql="SELECT * FROM person WHERE firstname='$firstname' AND lastname='$lastname' AND email='$email'";
	$result=$conn->query($sql);
	if($result->num_rows>0){
		//already in database, do not insert!
		header('location:index.php?page=persons');
	}else{
	 //insert into database. Both into person and placement tables
	 $sql="INSERT INTO person(lastname,firstname,email,salary)
		 VALUES('$lastname','$firstname','$email',$salary)";
	 $conn->query($sql);
	 //get the id of inserted record from auto-increment
	 $last_id=$conn->insert_id;
	 if($department!=0){
		$sql="INSERT INTO placement VALUES($last_id,$department)";
		$conn->query($sql);
	 }
	}
}
$conn->close();
header('location:index.php?page=persons');
?>






