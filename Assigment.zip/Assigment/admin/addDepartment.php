<?php
/*
	file:	admin/addDepartment.php
	desc:	Reads department from POST and if it is ok, saves into db
*/
if(!empty($_POST['department'])) $department=$_POST['department'];else header('location:index.php?page=department');
include('../db.php');
$sql="INSERT INTO department(department) VALUES('$department')";
$conn->query($sql);
$conn->close();
header('location:index.php?page=department');
?>