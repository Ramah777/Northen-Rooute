<?php
/*
	file:	admin/editdepartment.php
	desc:	Form for editing department
*/
if(!empty($_GET['depID'])) $depID=$_GET['depID'];else header('location:index.php?page=department');
if(!empty($_GET['update'])) $update=$_GET['update'];else $update='';
include('../db.php');
$sql="SELECT department FROM department WHERE depID=$depID";
$result=$conn->query($sql);  //runs the query in database
if($result->num_rows>0){
	$row=$result->fetch_assoc();
}
?>
<h4>Edit department</h4>
<?php
if(!empty($update)) echo '<p class="alert alert-success">Updated!</p>';
?>
<form action="updateDepartment.php" method="post">
		<input type="hidden" name="depID" value="<?php echo $depID?>" />
		Name: <input type="text" name="department" placeholder="Department name" value="<?php echo $row['department']?>" /><br />
		Remove department <input type="checkbox" name="removedep" /><br />
		<input type="submit" value="Update department" />
</form>