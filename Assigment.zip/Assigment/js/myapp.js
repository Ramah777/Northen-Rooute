/*
	file: 	js/myapp.js
	desc:	Sends the form fields to persons.php and gets the answer
			from there. Displays the answer in html-page
*/
$(document).ready(function(){
	getPersons();
	$("#keyword").keyup(function(event){
		getPersons();
	});
});

function getPersons(){
	//sends the form fields ot bmi.php
	$.post("persons.php",{
		keyword: $("#keyword").val()
	},function(data){
		//receive the answer from bmi.php as data
		$("#results").html(data);
	});
}