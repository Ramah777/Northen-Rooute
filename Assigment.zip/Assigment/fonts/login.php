<?php
/*
	file:	login.php
	desc:	Checks the username and password from db table user.
			If they are ok, saves session-information and redirects
			to go to admin-folder
*/
ob_start();
if(empty($_POST)) header('location:persons.php');

$error=false;
if(!empty($_POST['username'])) $username=$_POST['username'];else $error=true;
if(!empty($_POST['password'])) $password=$_POST['password'];else $error=true;
if(!$error){

		//username and password received, check from database
	include('db.php'); //use the database connection
	$username=$conn->real_escape_string($username);
	$password=$conn->real_escape_string($password);
	$sql = "SELECT username,password,userID,firstname,lastname FROM user
			WHERE username='$username'";

	$result=$conn->query($sql);  //runs the query in database
	if($result->num_rows>0){
		//username was found
		$row=$result->fetch_assoc();

		if(password_verify($password,$row['password'])){
			//password correct
			session_start();
			$_SESSION['userID']=$row['userID'];
			$_SESSION['name']=$row['firstname'].' '.$row['lastname'];
			
			header('location:http://localhost:8888/assignment/admin/index.php',true, 301);exit;

		}else header('location:persons.php');
	}else header('location:persons.php');
}else header('location:persons.php');
ob_end_flush();
?>











